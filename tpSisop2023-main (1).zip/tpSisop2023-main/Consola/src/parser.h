/*
 * parser.h
 *
 *  Created on: Apr 10, 2023
 *      Author: utnso
 */

#ifndef PARSER_H_
#define PARSER_H_

#include <stdio.h>
#include <stdlib.h>
#include <commons/string.h>

char* parsearInstrucciones(char* path);

#endif /* PARSER_H_ */
